<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>WhatsAventura</title>
</head>
<body>
  <h1>¡Bienvenido a WhatsAventura!</h1>
  <p>Juego de adivinanzas por WhatsApp. La inteligencia te paga.</p>
</body>
</html>


---
