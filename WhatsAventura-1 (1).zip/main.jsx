import React from 'react';
import ReactDOM from 'react-dom/client';
import WhatsAventuraApp from './WhatsAventuraApp';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<WhatsAventuraApp />);