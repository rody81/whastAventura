// Código reducido para demo. El código completo está en el documento original.
import React, { useState } from 'react';

export default function WhatsAventuraApp() {
  return (
    <div className="text-center p-4">
      <h1 className="text-3xl font-bold">WhatsAventura</h1>
      <p className="mt-4">¡Tu inteligencia te paga!</p>
    </div>
  );
}